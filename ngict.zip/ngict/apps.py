from django.apps import AppConfig


class NgictConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ngict'
